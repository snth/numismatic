Numismatic - Coin Collecting for Digital Assets
===============================================

|Join the chat at https://gitter.im/numismatic-chat/Lobby|

Getting started
---------------

::

    git clone https://github.com/snth/numismatic.git
    cd numismatic
    pip install -e .

Run
---

Run the ``coin`` script from anywhere and explore from there

::

    coin

    coin list

    coin info

    coin listen collect run

.. |Join the chat at https://gitter.im/numismatic-chat/Lobby| image:: https://badges.gitter.im/numismatic-chat/Lobby.svg
   :target: https://gitter.im/numismatic-chat/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge
